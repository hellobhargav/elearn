var { greet1, msg1 } = require("./arrow")

console.log(greet1());
console.log(msg1("Elearn"));