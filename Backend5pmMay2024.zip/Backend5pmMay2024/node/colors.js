var colors = require("colors");

console.log("Welcome to Node JS".green);
console.log("Error Found !".red);