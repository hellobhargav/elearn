// console.log("Started");

// setTimeout(() => {
//     console.log("Process");
// }, 5000)

// console.log("Finished");


var a = 10;
var b = 40;
setTimeout(() => {
    b = 90;
}, 2000)

console.log(a + b);