var greet = () => {
    return ("Welcome to Elearn Infotech");
}
let msg = (name) => {
    return ("We are Hiring for " + name);
}

module.exports.greet1 = greet

module.exports.msg1 = msg