console.log("Dir Path : " , __dirname);
console.log("File Path : " , __filename);